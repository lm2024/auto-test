SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS auto_test DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE auto_test;

-- =============================================
-- 分类字典表
-- =============================================
DROP TABLE IF EXISTS `dict_category`;
CREATE TABLE `dict_category` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `category_type` varchar(32) NOT NULL COMMENT '分类类型：system=系统分类，func=功能分类',
  `category_code` varchar(64) NOT NULL COMMENT '分类编码',
  `category_name` varchar(128) NOT NULL COMMENT '分类名称',
  `sort_order` int DEFAULT '0' COMMENT '排序号',
  `status` int DEFAULT '1' COMMENT '状态：0=禁用，1=可用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_code` (`category_type`,`category_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类字典表';

-- =============================================
-- 系统配置表
-- =============================================
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `config_key` varchar(255) NOT NULL COMMENT '配置键',
  `config_value` longtext COMMENT '配置值',
  `config_desc` varchar(512) DEFAULT NULL COMMENT '配置描述',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';

-- =============================================
-- 测试账号管理表
-- =============================================
DROP TABLE IF EXISTS `test_account`;
CREATE TABLE `test_account` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account_code` varchar(64) NOT NULL COMMENT '账号编码',
  `account_name` varchar(128) NOT NULL COMMENT '显示名称',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `product_code` varchar(64) DEFAULT NULL COMMENT '所属产品编码',
  `system_name` varchar(128) DEFAULT NULL COMMENT '所属系统',
  `username` varchar(128) NOT NULL COMMENT '登录用户名',
  `password` varchar(256) NOT NULL COMMENT '登录密码（AES加密存储）',
  `auth_type` varchar(32) NOT NULL COMMENT '认证类型：SSO/PASSWORD/TOKEN/CERTIFICATE',
  `auth_config` text COMMENT '认证配置JSON',
  `login_type` varchar(32) DEFAULT 'HTTP' COMMENT '登录类型',
  `login_config` json COMMENT '登录详细配置',
  `login_script` text COMMENT '自定义登录脚本',
  `status` int DEFAULT '1' COMMENT '状态：0=禁用，1=可用，2=锁定',
  `last_used_time` datetime DEFAULT NULL COMMENT '最后使用时间',
  `lock_until` datetime DEFAULT NULL COMMENT '锁定截止时间',
  `valid_from` datetime DEFAULT NULL COMMENT '账号有效期开始',
  `valid_until` datetime DEFAULT NULL COMMENT '账号有效期结束',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_code` (`account_code`),
  KEY `idx_status` (`status`),
  KEY `idx_account_tenant` (`tenant_id`),
  KEY `idx_account_product` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测试账号管理表';

-- =============================================
-- 测试账号使用记录表
-- =============================================
DROP TABLE IF EXISTS `test_account_usage`;
CREATE TABLE `test_account_usage` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account_id` bigint NOT NULL COMMENT '账号ID',
  `account_code` varchar(64) NOT NULL COMMENT '账号编码快照',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `user_id` bigint DEFAULT NULL COMMENT '使用人员ID',
  `operator_name` varchar(128) DEFAULT NULL COMMENT '使用人员或系统名称',
  `execution_id` varchar(32) DEFAULT NULL COMMENT '执行ID',
  `task_id` bigint DEFAULT NULL COMMENT '定时任务ID',
  `chain_code` varchar(64) DEFAULT NULL COMMENT '使用链路',
  `data_pool_code` varchar(64) DEFAULT NULL COMMENT '使用数据池',
  `usage_type` varchar(32) DEFAULT NULL COMMENT '使用类型',
  `status` varchar(16) NOT NULL DEFAULT 'RUNNING' COMMENT '使用状态',
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `ended_at` datetime DEFAULT NULL COMMENT '结束时间',
  `duration_ms` bigint DEFAULT NULL COMMENT '使用时长毫秒',
  `release_reason` varchar(128) DEFAULT NULL COMMENT '释放原因',
  PRIMARY KEY (`id`),
  KEY `idx_account_usage_account` (`account_id`,`started_at`),
  KEY `idx_account_usage_execution` (`execution_id`),
  KEY `idx_account_usage_tenant` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测试账号使用记录表';

-- =============================================
-- 数据池主表
-- =============================================
DROP TABLE IF EXISTS `test_data_pool_row`;
DROP TABLE IF EXISTS `test_data_pool`;
CREATE TABLE `test_data_pool` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pool_code` varchar(64) NOT NULL COMMENT '数据池编码',
  `pool_name` varchar(256) NOT NULL COMMENT '数据池名称',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `product_code` varchar(64) DEFAULT NULL COMMENT '所属产品编码',
  `description` varchar(512) DEFAULT NULL COMMENT '描述',
  `column_defs` json NOT NULL COMMENT '列定义',
  `status` tinyint DEFAULT 1 COMMENT '状态',
  `create_by` varchar(64) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uk_pool_code` (`pool_code`), KEY `idx_tenant` (`tenant_id`),
  KEY `idx_product` (`product_code`), KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据池';

CREATE TABLE `test_data_pool_row` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pool_id` bigint NOT NULL COMMENT '所属数据池ID',
  `row_index` int NOT NULL COMMENT '行号',
  `row_data` json NOT NULL COMMENT '行数据',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uk_pool_row` (`pool_id`,`row_index`), KEY `idx_pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据池行数据';

-- =============================================
-- 测试链路表
-- =============================================
DROP TABLE IF EXISTS `test_chain`;
CREATE TABLE `test_chain` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `chain_code` varchar(64) NOT NULL COMMENT '链路编码',
  `chain_name` varchar(128) NOT NULL COMMENT '链路名称',
  `execute_mode` tinyint NOT NULL DEFAULT '1' COMMENT '执行模式: 1=全串行, 2=分组并行',
  `description` text COMMENT '链路描述',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态: 1=启用, 0=禁用',
  `current_version` int NOT NULL DEFAULT '1' COMMENT '当前展示版本号（回放/版本快照功能）',
  `chain_fingerprint` varchar(128) DEFAULT NULL COMMENT '链路指纹(MD5)（回放/版本快照功能）',
  `graph_data` longtext COMMENT 'X6画布图数据(graph.toJSON())，编排与执行顺序的唯一真相来源',
  `biz_oper_trace_id` varchar(64) DEFAULT NULL COMMENT '操作级TraceId，关联一次用户操作的完整链路',
  `account_code` varchar(64) DEFAULT NULL COMMENT '绑定的测试账号编码',
  `system_category` varchar(64) DEFAULT NULL COMMENT '系统分类',
  `func_category` varchar(64) DEFAULT NULL COMMENT '功能分类',
  `priority` int DEFAULT '2' COMMENT '优先级：0=P0核心回归，1=P1常规回归，2=P2低频验证',
  `category_id` bigint DEFAULT NULL COMMENT '树形分类ID',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `product_code` varchar(64) DEFAULT NULL COMMENT '所属产品编码',
  `login_chain_code` varchar(64) DEFAULT NULL COMMENT '前置登录链路编码',
  `login_timeout` int DEFAULT '30000' COMMENT '登录超时(ms)',
  `data_pool_code` varchar(64) DEFAULT NULL COMMENT '绑定的数据池编码',
  `param_mode` varchar(16) DEFAULT 'NONE' COMMENT '参数模式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_chain_code` (`chain_code`),
  KEY `idx_chain_name` (`chain_name`),
  KEY `idx_execute_mode` (`execute_mode`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测试链路表';

-- =============================================
-- 测试节点配置表
-- =============================================
DROP TABLE IF EXISTS `test_node_config`;
CREATE TABLE `test_node_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `chain_code` varchar(64) NOT NULL COMMENT '所属链路编码',
  `node_id` bigint NOT NULL COMMENT '节点ID',
  `node_code` varchar(64) NOT NULL COMMENT '节点编码',
  `node_name` varchar(128) NOT NULL COMMENT '节点名称',
  `node_type` varchar(16) NOT NULL DEFAULT 'HTTP' COMMENT '节点类型',
  `interface_scope` varchar(16) DEFAULT NULL COMMENT '内外网范围: INTERNAL=内网, EXTERNAL=外网, UNKNOWN=未识别',
  `target_system` varchar(64) DEFAULT NULL COMMENT '归属系统编码，关联 sys_system_registry.system_code',
  `request_url` text NOT NULL COMMENT '请求URL',
  `request_method` varchar(10) NOT NULL COMMENT '请求方法',
  `request_headers` longtext COMMENT '请求头(JSON格式)',
  `body_type` varchar(32) DEFAULT NULL COMMENT '请求体类型',
  `body_data` longtext COMMENT '请求体内容',
  `extract_rules` longtext COMMENT '变量提取规则(JSON)',
  `assert_rules` longtext COMMENT '断言规则(JSON)',
  `variable_mapping` longtext COMMENT '变量占位符映射(JSON)',
  `delay_seconds` int DEFAULT '0' COMMENT '执行后等待秒数',
  `biz_oper_trace_id` varchar(64) DEFAULT NULL COMMENT '操作级TraceId',
  `trigger_event` varchar(32) DEFAULT NULL COMMENT '触发事件类型',
  `target_dom` varchar(256) DEFAULT NULL COMMENT '操作DOM选择器',
  `page_url` varchar(512) DEFAULT NULL COMMENT '当前页面地址',
  `window_id` varchar(64) DEFAULT NULL COMMENT '窗口ID',
  `is_ignored` tinyint DEFAULT '0' COMMENT '是否忽略',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_chain_node_code` (`chain_code`,`node_code`),
  UNIQUE KEY `uk_chain_node_id` (`chain_code`,`node_id`),
  KEY `idx_chain_code` (`chain_code`),
  KEY `idx_target_system` (`target_system`),
  KEY `idx_interface_scope` (`interface_scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测试节点配置表';

-- =============================================
-- 执行主日志表
-- =============================================
DROP TABLE IF EXISTS `test_execute_main`;
CREATE TABLE `test_execute_main` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `execution_id` varchar(32) NOT NULL COMMENT '执行ID',
  `chain_code` varchar(64) NOT NULL COMMENT '关联链路编码',
  `round_number` int DEFAULT NULL COMMENT '轮次编号',
  `task_id` bigint DEFAULT NULL COMMENT '关联定时任务ID',
  `status` varchar(16) NOT NULL DEFAULT 'RUNNING' COMMENT '执行状态: RUNNING/SUCCESS/FAILED',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `total_cost_ms` bigint DEFAULT NULL COMMENT '总耗时(毫秒)',
  `error_message` text COMMENT '全局错误信息',
  `node_count` int DEFAULT NULL COMMENT '节点总数',
  `success_count` int DEFAULT NULL COMMENT '成功节点数',
  `fail_count` int DEFAULT NULL COMMENT '失败节点数',
  `skip_count` int DEFAULT NULL COMMENT '跳过节点数',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_execution_id` (`execution_id`),
  KEY `idx_chain_code` (`chain_code`),
  KEY `idx_status` (`status`),
  KEY `idx_start_time` (`start_time`),
  KEY `idx_chain_status` (`chain_code`,`status`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='执行主日志表';

-- =============================================
-- 节点明细日志表
-- =============================================
DROP TABLE IF EXISTS `test_node_execute_log`;
CREATE TABLE `test_node_execute_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `execution_id` varchar(32) NOT NULL COMMENT '关联执行ID',
  `node_code` varchar(64) NOT NULL COMMENT '节点编码',
  `node_name` varchar(128) DEFAULT NULL COMMENT '节点名称',
  `status` varchar(16) NOT NULL COMMENT '执行状态',
  `request_url` text COMMENT '请求URL',
  `request_method` varchar(10) DEFAULT NULL COMMENT '请求方法',
  `request_headers` longtext COMMENT '请求头',
  `request_body` longtext COMMENT '请求体',
  `response_code` int DEFAULT NULL COMMENT '响应码',
  `response_headers` longtext COMMENT '响应头',
  `response_body` longtext COMMENT '响应体',
  `cost_ms` bigint DEFAULT NULL COMMENT '执行耗时(毫秒)',
  `error_message` text COMMENT '错误信息',
  `extracted_vars` longtext COMMENT '提取的变量(JSON)',
  `start_time` datetime DEFAULT NULL COMMENT '节点开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '节点结束时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `biz_oper_trace_id` varchar(64) DEFAULT NULL COMMENT '业务操作TraceId(用于分组视图)',
  `sort_no` int DEFAULT NULL COMMENT '节点排序号',
  PRIMARY KEY (`id`),
  KEY `idx_execution_id` (`execution_id`),
  KEY `idx_node_code` (`node_code`),
  KEY `idx_execution_node` (`execution_id`,`node_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点明细日志表';

-- =============================================
-- 全局变量表（跨链路复用的变量池）
-- =============================================
DROP TABLE IF EXISTS `test_global_variable`;
CREATE TABLE `test_global_variable` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `var_key` varchar(128) NOT NULL COMMENT '变量名，引用方式 ${var_key}',
  `var_value` longtext COMMENT '变量值',
  `var_type` varchar(16) NOT NULL DEFAULT 'STRING' COMMENT '值类型: STRING/NUMBER/BOOLEAN/JSON',
  `scope` varchar(16) NOT NULL DEFAULT 'GLOBAL' COMMENT '作用域: GLOBAL=全局, CHAIN=链路级',
  `chain_code` varchar(64) DEFAULT NULL COMMENT 'scope=CHAIN 时归属的链路编码',
  `is_secret` tinyint NOT NULL DEFAULT '0' COMMENT '是否敏感值: 1=前端脱敏展示',
  `description` varchar(512) DEFAULT NULL COMMENT '变量说明',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态: 1=启用, 0=禁用',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scope_chain_key` (`scope`,`chain_code`,`var_key`),
  KEY `idx_var_key` (`var_key`),
  KEY `idx_chain_code` (`chain_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='全局/链路级变量表';

-- =============================================
-- 系统注册表（内外网识别 + 系统调用关系图的数据源）
-- =============================================
DROP TABLE IF EXISTS `sys_system_registry`;
CREATE TABLE `sys_system_registry` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `system_code` varchar(64) NOT NULL COMMENT '系统编码',
  `system_name` varchar(128) NOT NULL COMMENT '系统名称',
  `scope` varchar(16) NOT NULL DEFAULT 'INTERNAL' COMMENT '内外网: INTERNAL=内网, EXTERNAL=外网',
  `domain_patterns` text COMMENT '域名匹配规则，多个用英文逗号分隔，支持 *.example.com 通配',
  `ip_ranges` text COMMENT 'IP段匹配规则(CIDR)，多个用英文逗号分隔，如 10.0.0.0/8',
  `category` varchar(128) DEFAULT NULL COMMENT '系统分类',
  `owner` varchar(64) DEFAULT NULL COMMENT '负责人',
  `description` varchar(512) DEFAULT NULL COMMENT '系统说明',
  `sort_order` int DEFAULT '0' COMMENT '排序号',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态: 1=启用, 0=禁用',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_system_code` (`system_code`),
  KEY `idx_scope` (`scope`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统注册表';

-- =============================================
-- 租户表
-- =============================================
DROP TABLE IF EXISTS `sys_tenant`;
CREATE TABLE `sys_tenant` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_code` varchar(64) NOT NULL COMMENT '租户编码',
  `tenant_name` varchar(128) NOT NULL COMMENT '租户名称',
  `status` int DEFAULT '1' COMMENT '状态：0=禁用，1=可用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_code` (`tenant_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='租户表';

-- =============================================
-- 系统用户表
-- =============================================
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `password` varchar(256) NOT NULL COMMENT '密码（BCrypt加密）',
  `display_name` varchar(128) DEFAULT NULL COMMENT '显示名称',
  `role` varchar(32) NOT NULL DEFAULT 'USER' COMMENT '角色：ADMIN/USER',
  `tenant_id` bigint DEFAULT NULL COMMENT '所属租户ID',
  `status` int DEFAULT '1' COMMENT '状态：0=禁用，1=可用',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- =============================================
-- SSO用户映射表
-- =============================================
DROP TABLE IF EXISTS `sys_user_sso`;
CREATE TABLE `sys_user_sso` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` bigint NOT NULL COMMENT '关联用户ID',
  `sso_provider` varchar(64) DEFAULT NULL COMMENT 'SSO提供商',
  `sso_subject` varchar(128) NOT NULL COMMENT 'SSO用户标识',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sso` (`sso_provider`, `sso_subject`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='SSO用户映射表';

-- =============================================
-- 树形分类表
-- =============================================
DROP TABLE IF EXISTS `sys_category`;
CREATE TABLE `sys_category` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `parent_id` bigint DEFAULT '0' COMMENT '父分类ID，0表示根节点',
  `category_name` varchar(128) NOT NULL COMMENT '分类名称',
  `sort_order` int DEFAULT '0' COMMENT '排序号',
  `icon` varchar(64) DEFAULT NULL COMMENT '图标',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `status` int DEFAULT '1' COMMENT '状态：0=禁用，1=可用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_category_tree` (`tenant_id`, `parent_id`, `status`, `sort_order`, `id`),
  KEY `idx_category_name_prefix` (`category_name`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='树形分类表';

-- =============================================
-- 定时任务表
-- =============================================
DROP TABLE IF EXISTS `sys_scheduled_task`;
CREATE TABLE `sys_scheduled_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `task_name` varchar(128) NOT NULL COMMENT '任务名称',
  `task_type` varchar(32) NOT NULL COMMENT '任务类型：SINGLE=单链路，CATEGORY=按分类',
  `chain_code` varchar(64) DEFAULT NULL COMMENT '链路编码（SINGLE类型）',
  `category_id` bigint DEFAULT NULL COMMENT '分类ID（CATEGORY类型）',
  `cron_expression` varchar(64) DEFAULT NULL COMMENT 'Cron表达式',
  `interval_minutes` int DEFAULT NULL COMMENT '间隔分钟数',
  `round_count` int DEFAULT '1' COMMENT '执行轮数',
  `round_interval_ms` int DEFAULT '0' COMMENT '轮次间隔毫秒',
  `use_data_pool` tinyint DEFAULT '0' COMMENT '是否使用数据池',
  `data_pool_code` varchar(64) DEFAULT NULL COMMENT '数据池编码',
  `enabled` int DEFAULT '1' COMMENT '是否启用：0=禁用，1=启用',
  `last_run_time` datetime DEFAULT NULL COMMENT '上次执行时间',
  `next_run_time` datetime DEFAULT NULL COMMENT '下次执行时间',
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定时任务表';

-- =============================================
-- 定时任务执行日志表
-- =============================================
DROP TABLE IF EXISTS `sys_task_execute_log`;
CREATE TABLE `sys_task_execute_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `task_id` bigint NOT NULL COMMENT '关联任务ID',
  `execution_ids` text COMMENT '执行ID列表（逗号分隔）',
  `status` varchar(16) DEFAULT NULL COMMENT '执行状态',
  `trigger_type` varchar(32) DEFAULT NULL COMMENT '触发类型：SCHEDULED/MANUAL',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `error_message` text COMMENT '错误信息',
  `round_number` int DEFAULT NULL COMMENT '当前轮次',
  `total_rounds` int DEFAULT NULL COMMENT '总轮数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定时任务执行日志表';

-- =============================================
-- 产品表（多租户下按产品维度组织链路/账号/数据池）
-- =============================================
DROP TABLE IF EXISTS `sys_product`;
CREATE TABLE `sys_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `product_code` varchar(64) NOT NULL COMMENT '产品编码（英文标识）',
  `product_name` varchar(256) NOT NULL COMMENT '产品名称（支持中英文）',
  `tenant_id` bigint NOT NULL COMMENT '所属租户ID',
  `description` varchar(512) DEFAULT NULL COMMENT '描述',
  `status` tinyint DEFAULT 1 COMMENT '状态: 1启用 0禁用',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_code` (`product_code`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='产品表';

-- =============================================
-- 链路版本快照表（回放/版本管理功能）
-- =============================================
DROP TABLE IF EXISTS `test_chain_version`;
CREATE TABLE `test_chain_version` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `chain_code` varchar(64) NOT NULL COMMENT '链路编码',
  `chain_fingerprint` varchar(128) NOT NULL COMMENT '链路指纹(MD5)',
  `version` int NOT NULL COMMENT '版本号',
  `chain_name` varchar(128) DEFAULT NULL COMMENT '链路名称快照',
  `execute_mode` tinyint DEFAULT '1' COMMENT '执行模式: 1=全串行, 2=分组并行',
  `description` text COMMENT '描述',
  `node_snapshot` longtext COMMENT '节点快照JSON',
  `diff_result` longtext COMMENT '与上一版本差异Diff结果JSON',
  `ai_analysis` text COMMENT 'AI分析结果',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '版本状态: ACTIVE/ARCHIVED',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_chain_version` (`chain_code`,`version`),
  KEY `idx_fingerprint` (`chain_fingerprint`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='链路版本快照表';

-- =============================================
-- 节点快照表（回放/版本管理功能）
-- =============================================
DROP TABLE IF EXISTS `test_node_snapshot`;
CREATE TABLE `test_node_snapshot` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `version_id` bigint NOT NULL COMMENT '关联 test_chain_version.id',
  `chain_code` varchar(64) NOT NULL COMMENT '链路编码',
  `node_id` bigint DEFAULT NULL COMMENT '节点ID',
  `node_code` varchar(64) DEFAULT NULL COMMENT '节点编码',
  `node_name` varchar(128) DEFAULT NULL COMMENT '节点名称',
  `node_type` varchar(16) DEFAULT 'HTTP' COMMENT '节点类型',
  `sort_no` int DEFAULT NULL COMMENT '节点排序号',
  `parallel_group` varchar(32) DEFAULT NULL COMMENT '并行分组',
  `request_url` text COMMENT '请求URL',
  `request_method` varchar(10) DEFAULT NULL COMMENT '请求方法',
  `request_headers` longtext COMMENT '请求头JSON',
  `body_type` varchar(32) DEFAULT NULL COMMENT 'Body类型',
  `body_data` longtext COMMENT '请求体数据',
  `response_code` int DEFAULT NULL COMMENT '响应状态码',
  `response_headers` longtext COMMENT '响应头JSON',
  `response_body` longtext COMMENT '响应体',
  `duration_ms` bigint DEFAULT NULL COMMENT '耗时(ms)',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_version_id` (`version_id`),
  KEY `idx_chain_code` (`chain_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点快照表';
-- ================================================================
-- 演示数据（电商场景，覆盖所有菜单，便于理解系统用法）
-- 说明：账号密码使用 AES-ECB 加密（密钥 account.aes-key），
--       管理员/普通用户密码均为 Admin@123（BCrypt）
-- ================================================================

-- -------------------------------------------
-- 分类字典（系统分类 system / 功能分类 func）
-- -------------------------------------------
INSERT INTO `dict_category` (`id`, `category_type`, `category_code`, `category_name`, `sort_order`, `status`, `create_time`) VALUES
(11, 'system', 'user_mgmt', '用户管理', 1, 1, '2026-08-01 10:00:00'),
(12, 'system', 'order_system', '订单系统', 2, 1, '2026-08-01 10:00:00'),
(13, 'system', 'payment_system', '支付系统', 3, 1, '2026-08-01 10:00:00'),
(14, 'system', 'approval_flow', '审批流程', 4, 1, '2026-08-01 10:00:00'),
(15, 'system', 'data_query', '数据查询', 5, 1, '2026-08-01 10:00:00'),
(16, 'func', 'login_auth', '登录认证', 1, 1, '2026-08-01 10:00:00'),
(17, 'func', 'data_query', '数据查询', 2, 1, '2026-08-01 10:00:00'),
(18, 'func', 'data_create', '数据新增', 3, 1, '2026-08-01 10:00:00'),
(19, 'func', 'data_update', '数据修改', 4, 1, '2026-08-01 10:00:00'),
(20, 'func', 'data_delete', '数据删除', 5, 1, '2026-08-01 10:00:00');

-- -------------------------------------------
-- 租户
-- -------------------------------------------
INSERT INTO `sys_tenant` (`id`, `tenant_code`, `tenant_name`, `status`, `create_time`, `update_time`) VALUES
(1, 'default', '默认租户', 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(2, 'huadong', '华东事业部', 1, '2026-08-02 10:00:00', '2026-08-02 10:00:00'),
(3, 'huanan', '华南事业部', 1, '2026-08-03 10:00:00', '2026-08-03 10:00:00');

-- -------------------------------------------
-- 产品
-- -------------------------------------------
INSERT INTO `sys_product` (`id`, `product_code`, `product_name`, `tenant_id`, `description`, `status`, `create_by`, `create_time`, `update_time`) VALUES
(1, 'mall', '电商商城', 1, 'B2C 电商平台，覆盖商品、订单、支付全流程', 1, 'admin', '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(2, 'paygw', '支付网关', 1, '统一支付接入、渠道路由与对账', 1, 'admin', '2026-08-02 09:00:00', '2026-08-02 09:00:00'),
(3, 'crm', '客户管理系统', 1, '销售线索与客户跟进管理', 1, 'admin', '2026-08-03 09:00:00', '2026-08-03 09:00:00');

-- -------------------------------------------
-- 系统注册表（内外网识别 + 调用关系图数据源）
-- -------------------------------------------
INSERT INTO `sys_system_registry` (`id`, `system_code`, `system_name`, `scope`, `domain_patterns`, `ip_ranges`, `category`, `owner`, `description`, `sort_order`, `status`, `tenant_id`, `create_time`, `update_time`) VALUES
(1, 'ORDER_SERVICE', '订单中心', 'INTERNAL', '*.order.internal.example.com', '10.0.10.0/24', '电商核心', '张伟', '订单创建、查询、状态流转', 1, 1, 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(2, 'USER_SERVICE', '用户中心', 'INTERNAL', '*.user.internal.example.com', '10.0.20.0/24', '电商核心', '李娜', '用户注册、登录、会员信息', 2, 1, 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(3, 'GOODS_SERVICE', '商品中心', 'INTERNAL', '*.goods.internal.example.com', '10.0.30.0/24', '电商核心', '王强', '商品、库存、价格管理', 3, 1, 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(4, 'PAYMENT_GATEWAY', '支付网关', 'EXTERNAL', 'pay.example.com, *.pay.example.com', NULL, '电商核心', '赵敏', '第三方支付渠道接入与回调', 4, 1, 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00'),
(5, 'CRM_SYSTEM', '客户管理', 'EXTERNAL', 'crm.example.com', NULL, '业务系统', '陈杰', '销售线索与客户跟进', 5, 1, 1, '2026-08-01 09:00:00', '2026-08-01 09:00:00');

-- -------------------------------------------
-- 树形分类（用于链路的树形归档与筛选）
-- -------------------------------------------
INSERT INTO `sys_category` (`id`, `parent_id`, `category_name`, `sort_order`, `icon`, `tenant_id`, `status`, `create_time`, `update_time`) VALUES
(1, 0, '电商核心', 1, 'cart', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(2, 0, '用户与账号', 2, 'user', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(11, 1, '下单流程', 1, NULL, 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(12, 1, '支付流程', 2, NULL, 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(13, 1, '退款流程', 3, NULL, 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(21, 2, '登录注册', 1, NULL, 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00');

-- -------------------------------------------
-- 全局变量（跨链路复用，${var_key} 引用）
-- -------------------------------------------
INSERT INTO `test_global_variable` (`id`, `var_key`, `var_value`, `var_type`, `scope`, `chain_code`, `is_secret`, `description`, `status`, `tenant_id`, `create_time`, `update_time`) VALUES
(1, 'BASE_URL', 'https://mall.example.com', 'STRING', 'GLOBAL', NULL, 0, '电商主域名', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(2, 'ORDER_API_TOKEN', 'demo-token-order-2026', 'STRING', 'GLOBAL', NULL, 1, '订单接口访问令牌（敏感）', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(3, 'PAY_CALLBACK_SECRET', 'demo-callback-secret', 'STRING', 'GLOBAL', NULL, 1, '支付回调验签密钥（敏感）', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(4, 'DEFAULT_PAGE_SIZE', '20', 'NUMBER', 'GLOBAL', NULL, 0, '默认分页大小', 1, 1, '2026-08-01 10:00:00', '2026-08-01 10:00:00');

-- -------------------------------------------
-- 系统配置
-- -------------------------------------------
INSERT INTO `sys_config` (`id`, `config_key`, `config_value`, `config_desc`, `create_time`, `update_time`) VALUES
(1, 'ai.base-url', 'http://localhost:11434/v1', 'AI 服务地址', '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(2, 'ai.model', 'qwen-max', 'AI 模型名称', '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(3, 'exec.timeout-seconds', '120', '链路执行超时时间(秒)', '2026-08-01 10:00:00', '2026-08-01 10:00:00'),
(4, 'captcha.bypass', 'true', '验证码绕过开关（仅测试环境）', '2026-08-01 10:00:00', '2026-08-01 10:00:00');

-- -------------------------------------------
-- 测试账号（密码为 AES 密文，明文见备注）
-- -------------------------------------------
INSERT INTO `test_account` (`id`, `account_code`, `account_name`, `tenant_id`, `product_code`, `system_name`, `username`, `password`, `auth_type`, `auth_config`, `login_type`, `login_config`, `login_script`, `status`, `last_used_time`, `lock_until`, `valid_from`, `valid_until`, `create_time`, `update_time`) VALUES
(1, 'ACC_ORDER_ADMIN', '订单中心-管理员', 1, 'mall', '订单中心', 'order_admin', 'QiHCYBnIEjJwhCyISkIAXA==', 'PASSWORD', NULL, 'HTTP', '{"loginUrl":"https://mall.example.com/api/login","tokenField":"data.token"}', NULL, 1, '2026-08-13 09:30:00', NULL, '2026-08-01 00:00:00', '2026-12-31 23:59:59', '2026-08-01 10:00:00', '2026-08-13 09:30:00'),
(2, 'ACC_PAY_TEST', '支付网关-测试', 1, 'paygw', '支付网关', 'pay_tester', '9qpPpamw7oHL+I+0rsQpqQ==', 'PASSWORD', NULL, 'HTTP', '{"loginUrl":"https://pay.example.com/api/login"}', NULL, 1, '2026-08-13 14:20:00', NULL, NULL, NULL, '2026-08-02 10:00:00', '2026-08-13 14:20:00'),
(3, 'ACC_USER_TEST', '用户中心-测试', 1, 'mall', '用户中心', 'user_tester', 'S9p4v7UkTNiZC5UWCzIi3g==', 'PASSWORD', NULL, 'HTTP', '{"loginUrl":"https://mall.example.com/api/login"}', NULL, 1, '2026-08-12 10:00:00', NULL, NULL, NULL, '2026-08-02 10:00:00', '2026-08-12 10:00:00'),
(4, 'ACC_GOODS_TEST', '商品中心-测试', 1, 'mall', '商品中心', 'goods_tester', 'WMtAznDCi5mZPY64a5rE3g==', 'PASSWORD', NULL, 'HTTP', '{"loginUrl":"https://mall.example.com/api/login"}', NULL, 1, NULL, NULL, NULL, NULL, '2026-08-03 10:00:00', '2026-08-03 10:00:00'),
(5, 'ACC_CRM_TEST', 'CRM-测试', 1, 'crm', '客户管理', 'crm_tester', 'mn81SUlVi+lDBVMaA8//Nw==', 'PASSWORD', NULL, 'HTTP', '{"loginUrl":"https://crm.example.com/api/login"}', NULL, 0, NULL, NULL, NULL, NULL, '2026-08-03 10:00:00', '2026-08-03 10:00:00');

-- -------------------------------------------
-- 测试账号使用记录
-- -------------------------------------------
INSERT INTO `test_account_usage` (`id`, `account_id`, `account_code`, `tenant_id`, `user_id`, `operator_name`, `execution_id`, `task_id`, `chain_code`, `data_pool_code`, `usage_type`, `status`, `started_at`, `ended_at`, `duration_ms`, `release_reason`) VALUES
(1, 1, 'ACC_ORDER_ADMIN', 1, 1, 'admin', 'EXEC_2026081301', NULL, 'CHAIN_MALL_ORDER', 'POOL_ORDER', 'EXECUTION', 'RELEASED', '2026-08-13 09:30:00', '2026-08-13 09:30:12', 12000, '执行完成自动释放'),
(2, 3, 'ACC_USER_TEST', 1, 1, 'admin', 'EXEC_2026081302', NULL, 'CHAIN_MALL_LOGIN', NULL, 'EXECUTION', 'RELEASED', '2026-08-13 09:45:00', '2026-08-13 09:45:08', 8000, '执行完成自动释放'),
(3, 2, 'ACC_PAY_TEST', 1, 1, 'admin', 'EXEC_2026081401', NULL, 'CHAIN_REFUND', NULL, 'EXECUTION', 'RELEASED', '2026-08-14 08:00:00', '2026-08-14 08:00:15', 15000, '执行完成自动释放');

-- -------------------------------------------
-- 测试链路
-- -------------------------------------------
INSERT INTO `test_chain` (`id`, `chain_code`, `chain_name`, `execute_mode`, `description`, `create_time`, `update_time`, `create_by`, `status`, `graph_data`, `biz_oper_trace_id`, `account_code`, `system_category`, `func_category`, `priority`, `category_id`, `tenant_id`, `product_code`, `login_chain_code`, `login_timeout`, `data_pool_code`, `param_mode`) VALUES
(1, 'CHAIN_MALL_ORDER', '电商下单主链路', 1, '登录→浏览商品→创建订单→支付，电商核心回归链路', '2026-08-05 10:00:00', '2026-08-13 09:30:00', 'admin', 1, NULL, NULL, 'ACC_ORDER_ADMIN', 'order_system', 'data_create', 0, 11, 1, 'mall', NULL, 30000, 'POOL_ORDER', 'DYNAMIC'),
(2, 'CHAIN_MALL_LOGIN', '用户登录链路', 1, '账号密码登录并获取访问令牌', '2026-08-05 11:00:00', '2026-08-13 09:45:00', 'admin', 1, NULL, NULL, 'ACC_USER_TEST', 'user_mgmt', 'login_auth', 0, 21, 1, 'mall', NULL, 30000, NULL, 'NONE'),
(3, 'CHAIN_ORDER_QUERY', '订单查询链路', 1, '按条件分页查询订单列表并校验关键字段', '2026-08-06 10:00:00', '2026-08-13 10:00:00', 'admin', 1, NULL, NULL, 'ACC_ORDER_ADMIN', 'order_system', 'data_query', 1, 11, 1, 'mall', NULL, 30000, NULL, 'NONE'),
(4, 'CHAIN_REFUND', '退款流程链路', 2, '发起退款→风控审核→退款回调，分组并行', '2026-08-07 10:00:00', '2026-08-14 08:00:00', 'admin', 1, NULL, NULL, 'ACC_ORDER_ADMIN', 'payment_system', 'data_update', 1, 13, 1, 'mall', NULL, 30000, NULL, 'NONE'),
(5, 'CHAIN_GOODS_PUBLISH', '商品上架链路', 1, '创建商品→库存校验→上架', '2026-08-08 10:00:00', '2026-08-12 16:00:00', 'admin', 1, NULL, NULL, 'ACC_GOODS_TEST', 'order_system', 'data_create', 2, 11, 1, 'mall', NULL, 30000, NULL, 'NONE');

-- -------------------------------------------
-- 节点配置（每条链路下的接口节点）
-- -------------------------------------------
INSERT INTO `test_node_config` (`id`, `chain_code`, `node_id`, `node_code`, `node_name`, `node_type`, `interface_scope`, `target_system`, `request_url`, `request_method`, `request_headers`, `body_type`, `body_data`, `extract_rules`, `assert_rules`, `variable_mapping`, `delay_seconds`, `biz_oper_trace_id`, `trigger_event`, `target_dom`, `page_url`, `window_id`, `is_ignored`, `create_time`, `update_time`) VALUES
(1, 'CHAIN_MALL_ORDER', 1, 'NODE_MALL_ORDER_01', '登录获取令牌', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"username":"order_admin","password":"Order@2026"}', '{"rules":[{"varName":"token","jsonPath":"$.data.token"}]}', '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(2, 'CHAIN_MALL_ORDER', 2, 'NODE_MALL_ORDER_02', '查询商品列表', 'HTTP', 'INTERNAL', 'GOODS_SERVICE', 'https://mall.example.com/api/goods/list?pageNo=1&pageSize=10', 'GET', '{"Authorization":"Bearer ${token}"}', NULL, NULL, NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(3, 'CHAIN_MALL_ORDER', 3, 'NODE_MALL_ORDER_03', '创建订单', 'HTTP', 'INTERNAL', 'ORDER_SERVICE', 'https://mall.example.com/api/order/create', 'POST', '{"Content-Type":"application/json","Authorization":"Bearer ${token}"}', 'JSON', '{"productId":"P001","amount":199,"address":"上海市浦东新区"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(4, 'CHAIN_MALL_ORDER', 4, 'NODE_MALL_ORDER_04', '发起支付', 'HTTP', 'EXTERNAL', 'PAYMENT_GATEWAY', 'https://pay.example.com/api/pay/create', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"orderId":"${orderId}","amount":199}', '{"rules":[{"varName":"payUrl","jsonPath":"$.data.payUrl"}]}', '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(5, 'CHAIN_MALL_ORDER', 5, 'NODE_MALL_ORDER_05', '查询订单状态', 'HTTP', 'INTERNAL', 'ORDER_SERVICE', 'https://mall.example.com/api/order/detail?orderId=${orderId}', 'GET', '{"Authorization":"Bearer ${token}"}', NULL, NULL, NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(6, 'CHAIN_MALL_LOGIN', 1, 'NODE_MALL_LOGIN_01', '账号密码登录', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"username":"user_tester","password":"User@2026"}', '{"rules":[{"varName":"token","jsonPath":"$.data.token"}]}', '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 11:00:00', '2026-08-05 11:00:00'),
(7, 'CHAIN_MALL_LOGIN', 2, 'NODE_MALL_LOGIN_02', '获取用户信息', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/user/profile', 'GET', '{"Authorization":"Bearer ${token}"}', NULL, NULL, NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 11:00:00', '2026-08-05 11:00:00'),
(8, 'CHAIN_MALL_LOGIN', 3, 'NODE_MALL_LOGIN_03', '校验令牌有效性', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/auth/check', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"token":"${token}"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-05 11:00:00', '2026-08-05 11:00:00'),
(9, 'CHAIN_ORDER_QUERY', 1, 'NODE_ORDER_QUERY_01', '登录获取令牌', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"username":"order_admin","password":"Order@2026"}', '{"rules":[{"varName":"token","jsonPath":"$.data.token"}]}', '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-06 10:00:00', '2026-08-06 10:00:00'),
(10, 'CHAIN_ORDER_QUERY', 2, 'NODE_ORDER_QUERY_02', '分页查询订单', 'HTTP', 'INTERNAL', 'ORDER_SERVICE', 'https://mall.example.com/api/order/list?pageNo=1&pageSize=20&status=PAID', 'GET', '{"Authorization":"Bearer ${token}"}', NULL, NULL, NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-06 10:00:00', '2026-08-06 10:00:00'),
(11, 'CHAIN_REFUND', 1, 'NODE_REFUND_01', '发起退款', 'HTTP', 'INTERNAL', 'ORDER_SERVICE', 'https://mall.example.com/api/refund/apply', 'POST', '{"Content-Type":"application/json","Authorization":"Bearer ${token}"}', 'JSON', '{"orderId":"${orderId}","reason":"用户申请退款"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-07 10:00:00', '2026-08-07 10:00:00'),
(12, 'CHAIN_REFUND', 2, 'NODE_REFUND_02', '风控审核', 'HTTP', 'INTERNAL', 'ORDER_SERVICE', 'https://mall.example.com/api/refund/audit', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"refundId":"${refundId}","result":"PASS"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-07 10:00:00', '2026-08-07 10:00:00'),
(13, 'CHAIN_REFUND', 3, 'NODE_REFUND_03', '退款回调', 'HTTP', 'EXTERNAL', 'PAYMENT_GATEWAY', 'https://pay.example.com/api/refund/callback', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"refundId":"${refundId}","status":"SUCCESS"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-07 10:00:00', '2026-08-07 10:00:00'),
(14, 'CHAIN_GOODS_PUBLISH', 1, 'NODE_GOODS_PUBLISH_01', '登录获取令牌', 'HTTP', 'INTERNAL', 'USER_SERVICE', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"username":"goods_tester","password":"Goods@2026"}', '{"rules":[{"varName":"token","jsonPath":"$.data.token"}]}', '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-08 10:00:00', '2026-08-08 10:00:00'),
(15, 'CHAIN_GOODS_PUBLISH', 2, 'NODE_GOODS_PUBLISH_02', '创建商品', 'HTTP', 'INTERNAL', 'GOODS_SERVICE', 'https://mall.example.com/api/goods/create', 'POST', '{"Content-Type":"application/json","Authorization":"Bearer ${token}"}', 'JSON', '{"name":"测试商品","price":199,"stock":100}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-08 10:00:00', '2026-08-08 10:00:00'),
(16, 'CHAIN_GOODS_PUBLISH', 3, 'NODE_GOODS_PUBLISH_03', '商品上架', 'HTTP', 'INTERNAL', 'GOODS_SERVICE', 'https://mall.example.com/api/goods/publish', 'POST', '{"Content-Type":"application/json"}', 'JSON', '{"goodsId":"${goodsId}","action":"ON_SHELF"}', NULL, '{"statusCode":200,"body":{"$.code":0}}', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2026-08-08 10:00:00', '2026-08-08 10:00:00');

-- -------------------------------------------
-- 数据池（参数化测试数据源）
-- -------------------------------------------
INSERT INTO `test_data_pool` (`id`, `pool_code`, `pool_name`, `tenant_id`, `product_code`, `description`, `column_defs`, `status`, `create_by`, `create_time`, `update_time`) VALUES
(1, 'POOL_ORDER', '订单测试数据', 1, 'mall', '下单链路参数化数据：不同商品与收货地址组合', '[{"name":"orderId","type":"STRING","label":"订单号","required":true},{"name":"userId","type":"STRING","label":"用户ID","required":true},{"name":"productId","type":"STRING","label":"商品ID","required":true},{"name":"amount","type":"NUMBER","label":"金额","required":true}]', 1, 'admin', '2026-08-05 10:00:00', '2026-08-05 10:00:00'),
(2, 'POOL_USER', '用户测试数据', 1, 'mall', '登录链路参数化数据', '[{"name":"username","type":"STRING","label":"用户名","required":true},{"name":"password","type":"STRING","label":"密码","required":true}]', 1, 'admin', '2026-08-05 10:00:00', '2026-08-05 10:00:00');

INSERT INTO `test_data_pool_row` (`id`, `pool_id`, `row_index`, `row_data`, `create_time`) VALUES
(1, 1, 0, '{"orderId":"ORD20260801001","userId":"U1001","productId":"P001","amount":199.00}', '2026-08-05 10:00:00'),
(2, 1, 1, '{"orderId":"ORD20260801002","userId":"U1002","productId":"P002","amount":899.00}', '2026-08-05 10:00:00'),
(3, 1, 2, '{"orderId":"ORD20260801003","userId":"U1003","productId":"P003","amount":59.90}', '2026-08-05 10:00:00'),
(4, 2, 0, '{"username":"user_tester","password":"User@2026"}', '2026-08-05 10:00:00'),
(5, 2, 1, '{"username":"order_admin","password":"Order@2026"}', '2026-08-05 10:00:00');

-- -------------------------------------------
-- 执行记录
-- -------------------------------------------
INSERT INTO `test_execute_main` (`id`, `execution_id`, `chain_code`, `round_number`, `task_id`, `status`, `start_time`, `end_time`, `total_cost_ms`, `error_message`, `node_count`, `success_count`, `fail_count`, `skip_count`, `tenant_id`, `create_time`, `update_time`) VALUES
(1, 'EXEC_2026081301', 'CHAIN_MALL_ORDER', 1, NULL, 'SUCCESS', '2026-08-13 09:30:00', '2026-08-13 09:30:12', 12000, NULL, 5, 5, 0, 0, 1, '2026-08-13 09:30:00', '2026-08-13 09:30:12'),
(2, 'EXEC_2026081302', 'CHAIN_MALL_LOGIN', 1, NULL, 'SUCCESS', '2026-08-13 09:45:00', '2026-08-13 09:45:08', 8000, NULL, 3, 3, 0, 0, 1, '2026-08-13 09:45:00', '2026-08-13 09:45:08'),
(3, 'EXEC_2026081303', 'CHAIN_ORDER_QUERY', 1, NULL, 'SUCCESS', '2026-08-13 10:00:00', '2026-08-13 10:00:06', 6000, NULL, 2, 2, 0, 0, 1, '2026-08-13 10:00:00', '2026-08-13 10:00:06'),
(4, 'EXEC_2026081401', 'CHAIN_REFUND', 1, NULL, 'FAILED', '2026-08-14 08:00:00', '2026-08-14 08:00:15', 15000, '断言失败: 节点[退款回调] 响应码=500', 3, 2, 1, 0, 1, '2026-08-14 08:00:00', '2026-08-14 08:00:15'),
(5, 'EXEC_2026081402', 'CHAIN_GOODS_PUBLISH', 1, NULL, 'SUCCESS', '2026-08-14 08:30:00', '2026-08-14 08:30:09', 9000, NULL, 3, 3, 0, 0, 1, '2026-08-14 08:30:00', '2026-08-14 08:30:09');

-- -------------------------------------------
-- 节点执行明细（配合执行记录）
-- -------------------------------------------
INSERT INTO `test_node_execute_log` (`id`, `execution_id`, `node_code`, `node_name`, `status`, `request_url`, `request_method`, `request_headers`, `request_body`, `response_code`, `response_headers`, `response_body`, `cost_ms`, `error_message`, `extracted_vars`, `start_time`, `end_time`, `create_time`, `biz_oper_trace_id`, `sort_no`) VALUES
(1, 'EXEC_2026081301', 'NODE_MALL_ORDER_01', '登录获取令牌', 'SUCCESS', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', '{"username":"order_admin","password":"***"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"token":"mock-token-1"}}', 2100, NULL, '{"token":"mock-token-1"}', '2026-08-13 09:30:00', '2026-08-13 09:30:02', '2026-08-13 09:30:00', NULL, 1),
(2, 'EXEC_2026081301', 'NODE_MALL_ORDER_02', '查询商品列表', 'SUCCESS', 'https://mall.example.com/api/goods/list?pageNo=1&pageSize=10', 'GET', '{"Authorization":"Bearer mock-token-1"}', NULL, 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"total":3}}', 1800, NULL, NULL, '2026-08-13 09:30:03', '2026-08-13 09:30:05', '2026-08-13 09:30:03', NULL, 2),
(3, 'EXEC_2026081301', 'NODE_MALL_ORDER_03', '创建订单', 'SUCCESS', 'https://mall.example.com/api/order/create', 'POST', '{"Content-Type":"application/json"}', '{"productId":"P001","amount":199}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"orderId":"ORD20260801001"}}', 3200, NULL, '{"orderId":"ORD20260801001"}', '2026-08-13 09:30:05', '2026-08-13 09:30:08', '2026-08-13 09:30:05', NULL, 3),
(4, 'EXEC_2026081301', 'NODE_MALL_ORDER_04', '发起支付', 'SUCCESS', 'https://pay.example.com/api/pay/create', 'POST', '{"Content-Type":"application/json"}', '{"orderId":"ORD20260801001","amount":199}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"payUrl":"https://pay.example.com/pay/xxx"}}', 2800, NULL, '{"payUrl":"https://pay.example.com/pay/xxx"}', '2026-08-13 09:30:08', '2026-08-13 09:30:11', '2026-08-13 09:30:08', NULL, 4),
(5, 'EXEC_2026081301', 'NODE_MALL_ORDER_05', '查询订单状态', 'SUCCESS', 'https://mall.example.com/api/order/detail?orderId=ORD20260801001', 'GET', '{"Authorization":"Bearer mock-token-1"}', NULL, 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"status":"PAID"}}', 2100, NULL, NULL, '2026-08-13 09:30:11', '2026-08-13 09:30:12', '2026-08-13 09:30:11', NULL, 5),
(6, 'EXEC_2026081302', 'NODE_MALL_LOGIN_01', '账号密码登录', 'SUCCESS', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', '{"username":"user_tester","password":"***"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"token":"mock-token-2"}}', 2000, NULL, '{"token":"mock-token-2"}', '2026-08-13 09:45:00', '2026-08-13 09:45:02', '2026-08-13 09:45:00', NULL, 1),
(7, 'EXEC_2026081302', 'NODE_MALL_LOGIN_02', '获取用户信息', 'SUCCESS', 'https://mall.example.com/api/user/profile', 'GET', '{"Authorization":"Bearer mock-token-2"}', NULL, 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"nickname":"测试用户"}}', 1600, NULL, NULL, '2026-08-13 09:45:03', '2026-08-13 09:45:05', '2026-08-13 09:45:03', NULL, 2),
(8, 'EXEC_2026081302', 'NODE_MALL_LOGIN_03', '校验令牌有效性', 'SUCCESS', 'https://mall.example.com/api/auth/check', 'POST', '{"Content-Type":"application/json"}', '{"token":"mock-token-2"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"valid":true}}', 1200, NULL, NULL, '2026-08-13 09:45:06', '2026-08-13 09:45:08', '2026-08-13 09:45:06', NULL, 3),
(9, 'EXEC_2026081303', 'NODE_ORDER_QUERY_01', '登录获取令牌', 'SUCCESS', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', '{"username":"order_admin","password":"***"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"token":"mock-token-3"}}', 2100, NULL, '{"token":"mock-token-3"}', '2026-08-13 10:00:00', '2026-08-13 10:00:02', '2026-08-13 10:00:00', NULL, 1),
(10, 'EXEC_2026081303', 'NODE_ORDER_QUERY_02', '分页查询订单', 'SUCCESS', 'https://mall.example.com/api/order/list?pageNo=1&pageSize=20&status=PAID', 'GET', '{"Authorization":"Bearer mock-token-3"}', NULL, 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"total":42}}', 1800, NULL, NULL, '2026-08-13 10:00:03', '2026-08-13 10:00:06', '2026-08-13 10:00:03', NULL, 2),
(11, 'EXEC_2026081401', 'NODE_REFUND_01', '发起退款', 'SUCCESS', 'https://mall.example.com/api/refund/apply', 'POST', '{"Content-Type":"application/json"}', '{"orderId":"ORD20260801001","reason":"用户申请退款"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"refundId":"RF20260814001"}}', 3000, NULL, '{"refundId":"RF20260814001"}', '2026-08-14 08:00:00', '2026-08-14 08:00:03', '2026-08-14 08:00:00', NULL, 1),
(12, 'EXEC_2026081401', 'NODE_REFUND_02', '风控审核', 'SUCCESS', 'https://mall.example.com/api/refund/audit', 'POST', '{"Content-Type":"application/json"}', '{"refundId":"RF20260814001","result":"PASS"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"audit":"PASS"}}', 2400, NULL, NULL, '2026-08-14 08:00:04', '2026-08-14 08:00:06', '2026-08-14 08:00:04', NULL, 2),
(13, 'EXEC_2026081401', 'NODE_REFUND_03', '退款回调', 'FAILED', 'https://pay.example.com/api/refund/callback', 'POST', '{"Content-Type":"application/json"}', '{"refundId":"RF20260814001","status":"SUCCESS"}', 500, '{"Content-Type":"application/json"}', '{"code":500,"message":"internal error"}', 3800, '断言失败: 响应码=500', NULL, '2026-08-14 08:00:07', '2026-08-14 08:00:15', '2026-08-14 08:00:07', NULL, 3),
(14, 'EXEC_2026081402', 'NODE_GOODS_PUBLISH_01', '登录获取令牌', 'SUCCESS', 'https://mall.example.com/api/login', 'POST', '{"Content-Type":"application/json"}', '{"username":"goods_tester","password":"***"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"token":"mock-token-4"}}', 2000, NULL, '{"token":"mock-token-4"}', '2026-08-14 08:30:00', '2026-08-14 08:30:02', '2026-08-14 08:30:00', NULL, 1),
(15, 'EXEC_2026081402', 'NODE_GOODS_PUBLISH_02', '创建商品', 'SUCCESS', 'https://mall.example.com/api/goods/create', 'POST', '{"Content-Type":"application/json"}', '{"name":"测试商品","price":199,"stock":100}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"goodsId":"G20260814001"}}', 2600, NULL, '{"goodsId":"G20260814001"}', '2026-08-14 08:30:03', '2026-08-14 08:30:06', '2026-08-14 08:30:03', NULL, 2),
(16, 'EXEC_2026081402', 'NODE_GOODS_PUBLISH_03', '商品上架', 'SUCCESS', 'https://mall.example.com/api/goods/publish', 'POST', '{"Content-Type":"application/json"}', '{"goodsId":"G20260814001","action":"ON_SHELF"}', 200, '{"Content-Type":"application/json"}', '{"code":0,"data":{"status":"ON_SHELF"}}', 1800, NULL, NULL, '2026-08-14 08:30:07', '2026-08-14 08:30:09', '2026-08-14 08:30:07', NULL, 3);

-- -------------------------------------------
-- 定时任务
-- -------------------------------------------
INSERT INTO `sys_scheduled_task` (`id`, `task_name`, `task_type`, `chain_code`, `category_id`, `cron_expression`, `interval_minutes`, `round_count`, `round_interval_ms`, `use_data_pool`, `data_pool_code`, `enabled`, `last_run_time`, `next_run_time`, `tenant_id`, `create_time`, `update_time`) VALUES
(1, '电商核心每日回归', 'SINGLE', 'CHAIN_MALL_ORDER', NULL, '0 0 2 * * ?', NULL, 1, 0, 1, 'POOL_ORDER', 1, '2026-08-14 02:00:00', '2026-08-15 02:00:00', 1, '2026-08-05 10:00:00', '2026-08-14 02:00:00'),
(2, '登录链路每小时冒烟', 'SINGLE', 'CHAIN_MALL_LOGIN', NULL, '0 0 * * * ?', NULL, 1, 0, 0, NULL, 1, '2026-08-14 08:00:00', '2026-08-14 09:00:00', 1, '2026-08-06 10:00:00', '2026-08-14 08:00:00'),
(3, '下单分类按半小时回归', 'CATEGORY', NULL, 11, NULL, 30, 1, 0, 0, NULL, 0, NULL, NULL, 1, '2026-08-07 10:00:00', '2026-08-07 10:00:00');

-- -------------------------------------------
-- 定时任务执行日志
-- -------------------------------------------
INSERT INTO `sys_task_execute_log` (`id`, `task_id`, `execution_ids`, `status`, `trigger_type`, `start_time`, `end_time`, `error_message`, `round_number`, `total_rounds`, `create_time`) VALUES
(1, 1, 'EXEC_2026081301', 'SUCCESS', 'SCHEDULED', '2026-08-13 02:00:00', '2026-08-13 02:00:12', NULL, 1, 1, '2026-08-13 02:00:00'),
(2, 2, 'EXEC_2026081302', 'SUCCESS', 'SCHEDULED', '2026-08-13 08:00:00', '2026-08-13 08:00:08', NULL, 1, 1, '2026-08-13 08:00:00'),
(3, 1, 'EXEC_2026081401', 'FAILED', 'SCHEDULED', '2026-08-14 02:00:00', '2026-08-14 02:00:15', '断言失败: 节点[退款回调] 响应码=500', 1, 1, '2026-08-14 02:00:00');

-- -------------------------------------------
-- 用户（密码均为 Admin@123，BCrypt 加密）
-- -------------------------------------------
INSERT INTO `sys_user` (`id`, `username`, `password`, `display_name`, `role`, `tenant_id`, `status`, `last_login_time`, `create_time`, `update_time`) VALUES
(1, 'admin', '$2a$10$gmCiTTTMLVnMotdNYfbIOOH4TM4Vuqj42QBaLsWFNm4pseixi.VB2', '系统管理员', 'ADMIN', 1, 1, '2026-08-14 09:00:00', '2026-08-01 09:00:00', '2026-08-14 09:00:00'),
(2, 'zhangsan', '$2a$10$gmCiTTTMLVnMotdNYfbIOOH4TM4Vuqj42QBaLsWFNm4pseixi.VB2', '张伟', 'USER', 1, 1, '2026-08-13 18:00:00', '2026-08-05 10:00:00', '2026-08-13 18:00:00'),
(3, 'lisi', '$2a$10$gmCiTTTMLVnMotdNYfbIOOH4TM4Vuqj42QBaLsWFNm4pseixi.VB2', '李娜', 'USER', 2, 1, NULL, '2026-08-06 10:00:00', '2026-08-06 10:00:00');
